import React from "react";

const StockContext = React.createContext();

export default StockContext;
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PRO_XY.WebAPI.Constants
{
  public static class Dataset
  {
    public const string D1 = "SampleSuperstore";
    public const string D2 = "PRO_XY_Retail";
    public const string D3 = "PRO_XY_Banking";
  }
}

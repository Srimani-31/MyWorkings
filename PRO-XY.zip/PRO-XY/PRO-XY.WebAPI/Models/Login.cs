﻿namespace PRO_XY.WebAPI.Models
{
  public class Login
  {
    public string Username { get; set; }
    public string Password { get; set; }
  }
}
